
package summativetask1;

public class ApplicationRunner {

    public static void main(String[] args) {

        Mechanics.initialise();
    }
}
